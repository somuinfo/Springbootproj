package com.example.demo.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.PartnerDriver;
import com.example.demo.SaveADO;

@Controller
public class PartnerDriverController {
	
	@Autowired
	private PartnerDriver cabDriver;

	
	@Autowired
	private SaveADO objSaveAdo;
	
	@Autowired
	private ModelAndView mdlView;

	@GetMapping("/")
	public String Init()
	{
		return "index";
	}
	
	@GetMapping("/AddDriver")
	public ModelAndView sendForm()
	{
		mdlView.addObject("command", cabDriver);
		mdlView.setViewName("addCabDriver");
		return mdlView;
	}
	
	@PostMapping("addDriver")
	public String onSubmit(@ModelAttribute("passedBean") PartnerDriver driver)
	{
	   PartnerDriver res = objSaveAdo.save(driver);
	   if(res != null)
		return "success";
	   else
	   return "success";
	}

}
