package com.example.demo.Utils;

public interface ClientView {

}
