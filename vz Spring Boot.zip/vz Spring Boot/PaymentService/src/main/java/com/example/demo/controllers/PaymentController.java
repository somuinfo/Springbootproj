package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Payment;
import com.example.demo.repos.PaymentRepos;
//import com.netflix.discovery.EurekaClient;

import io.swagger.annotations.ApiOperation;


@RestController
public class PaymentController {
	
	@Autowired
	@Qualifier("ramesh")
	private Payment object;
	
	@Autowired
	private PaymentRepos repos;
	
	//@Autowired
	//private EurekaClient client;

	@Autowired
	@Qualifier("suresh")
	private Payment secondobject;

	@GetMapping("/showPayment")
	public Payment getPayment()
	{
		return object;
	}

	@GetMapping("/showAll")
	public List<Payment> findAll()
	{
		return repos.findAll();
	}

	@GetMapping("/FindByID/{id}")
	public Payment getPaymentByID(@PathVariable long id)
	{
		if(id == 102)
			return object;
		else
			return secondobject;
	}

	@PostMapping("/addPayment")
	@ApiOperation(value="this method return")
	public Payment AddPayment(Payment pmt)
	{
		Payment savedpmt = repos.save(pmt);
		return savedpmt;
	}

}
