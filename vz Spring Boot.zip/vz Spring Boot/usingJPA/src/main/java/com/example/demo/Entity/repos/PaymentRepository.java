package com.example.demo.Entity.repos;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.Entity.Payment;

public interface PaymentRepository extends CrudRepository<Payment, Long> {

}
