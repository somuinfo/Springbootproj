package com.example.demo;

public class Course {
	

	public Course() {
		super();
		
		System.out.println("course called prototype");
	}
	

}
