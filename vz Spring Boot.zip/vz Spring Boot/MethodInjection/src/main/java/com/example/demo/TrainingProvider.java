package com.example.demo;

import org.springframework.beans.factory.annotation.Lookup;

public abstract class TrainingProvider {
	private Course obj;
	/*
	public TrainingProvider(Course course) {
		super();
		this.obj = course;
		System.out.println("Traning provider called singleton1");
	}
	*/
	public TrainingProvider() {
		super();
		System.out.println("Traning provider called singleton");
	}

	@Lookup
	public abstract Course getFreshCourse();	
	

}
