package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class SearchDonorController {
	
	@Autowired
	public RestTemplate template;
	
	@Autowired
	public LoadBalancerClient balancedClient;
	
	
	@GetMapping("findDonor/{bloodGroup}")
	public String SearchDonor(@PathVariable String bloodGroup)
	{
	 ServiceInstance si = balancedClient.choose("search-blood-donor-service");
	 String baseUrl = si.getUri().toString();
	 
	 System.out.println(baseUrl);
	 
	 baseUrl = baseUrl + "/search/" + bloodGroup;
	 String res =	template.getForObject(baseUrl, String.class);
	 return res;
	}
	

}
