package com.example.demo.controllers;

import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
@EnableDiscoveryClient
public class SearchDonorController {
	
	@GetMapping("/search/{bloodGroup}")
	public String getDonorByGroup(@PathVariable String bloodGroup)
	{
		String donorName = "Ramesh";
		if(bloodGroup.equals("bpos")){
			donorName = "Rajesh";
		}
		return donorName;
	}

}
