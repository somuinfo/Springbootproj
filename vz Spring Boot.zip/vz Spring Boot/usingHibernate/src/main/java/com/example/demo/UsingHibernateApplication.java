package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import com.example.demo.Entity.Book;
import com.example.demo.services.BookServiceImpl;

@SpringBootApplication
public class UsingHibernateApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(UsingHibernateApplication.class, args);
		
	   BookServiceImpl bkimpl =	ctx.getBean(BookServiceImpl.class);
	   Book bk =	ctx.getBean(Book.class);
	   Long bkadded = bkimpl.addBooks(bk);
	   System.out.println("one book added with key" + bkadded);
	   System.out.println("books result : " + bkimpl.getBooks());
	   
	}
	
	@Bean
	public Book book()
	{
		return new Book(102, "Head first java", 450);
	}

}
