package com.example.demo.Model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Book {

	private long bookNumber;
	private String bookName;
	private Author auth;
	
}
