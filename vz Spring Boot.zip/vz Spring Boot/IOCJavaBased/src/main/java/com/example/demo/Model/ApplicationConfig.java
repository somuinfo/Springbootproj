package com.example.demo.Model;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationConfig {
	
	@Bean
	public Author author()
	{
		return new Author(101, "Somu");
	}
	
	@Bean
	public Book book()
	{
		return new Book(1111, "java", author() );
	}

}
