package com.example.demo;
import com.example.demo.Model.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class IocJavaBasedApplication {

	public static void main(String[] args) {
	 ConfigurableApplicationContext ctx = 	SpringApplication.run(IocJavaBasedApplication.class, args);
	 
	 Author som =  (Author) ctx.getBean("author");
	 Author raj =  (Author) ctx.getBean("raj");
	 Book  book =  (Book) ctx.getBean("book");
	 log.info(som.toString());
	 
	 log.info(raj.toString());
	 
	 log.info(book.toString());
	 
	}
	
	@Bean(name="raj")
	public Author author()
	{
		return new Author(101, "raj");
	}


}
