package com.example.demo.model;

import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.*;

@Component
public class Payment {

	private long tripId;
	private PaymentDriver driverName;
	private double Amount;
	
	public Payment(long tripId, PaymentDriver driverName, double amount) {
		super();
		this.tripId = tripId;
		this.driverName = driverName;
		Amount = amount;
	}

	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public long getTripId() {
		return tripId;
	}

	@Value("1111")
	public void setTripId(long tripId) {
		System.out.println("settrip id called");
		this.tripId = tripId;
	}

	public PaymentDriver getDriverName() {
		return driverName;
	}
	
	@Autowired
	public void setDriverName(PaymentDriver driverName) {
		System.out.println("set drivername called");
		this.driverName = driverName;
	}

	public double getAmount() {
		return Amount;
	}
	
	@Value("1000")
	public void setAmount(double amount) {
		System.out.println("set amount called");
		Amount = amount;
	}


	@Override
	public String toString() {
		return "Payment [tripId=" + tripId + ", driverName=" + driverName + ", Amount=" + Amount + "]";
	}


	
	
	
}
