package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.example.demo.model.Payment;
import com.example.demo.model.PaymentDriver;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class IocExample1Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(IocExample1Application.class, args);

		Payment payment = ctx.getBean(Payment.class);
		
		PaymentDriver pdriver = ctx.getBean(PaymentDriver.class);
		
		pdriver.setDriverId(1111);
		pdriver.setDriverName("somu");
		pdriver.setDriverRating("somu");
		pdriver.setDriverMobileNumber(98233);
				 
		
		log.info(payment.toString());
		 
	}

}
