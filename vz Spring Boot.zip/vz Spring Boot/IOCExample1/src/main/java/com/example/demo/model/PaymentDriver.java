package com.example.demo.model;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;

import org.springframework.beans.factory.annotation.*;

@Data
@Component
@AllArgsConstructor
public class PaymentDriver {

	private String driverName;
	private long driverId;
	private long driverMobileNumber;
	private String driverRating;
	
	
	
	
	
}
