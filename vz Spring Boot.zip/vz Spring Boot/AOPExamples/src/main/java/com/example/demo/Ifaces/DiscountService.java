package com.example.demo.Ifaces;

public interface DiscountService {
	
	public double CashDiscount();
	public String[] getCoupons();

}
